class Base {
  getURL() {
    // if data id return /id
    // else just url
  }
  toJSON() {
    // check if it is a class - return class.id
  }
};
