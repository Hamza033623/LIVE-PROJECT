const chai      = require('chai');
const sinon     = require('sinon');
const should    = chai.should();
const expect    = chai.expect;


describe('File Element', function () {
  it('Render Function', function () {
  },
  it('attacheEvents Function', function () {
  },
  it('update Function', function() {
  }
});

describe('File Dropzone', function () {
  it('Render Function', function () {
  },
  it('attacheEvents Function', function () {
  },
  it('update Function', function() {
  },
  it('create dropzone Function', function() {
  }
});
