const chai      = require('chai');
const sinon     = require('sinon');
const should    = chai.should();
const expect    = chai.expect;
const route     = require('./route.js');

// - Check field list
// - Check phone update feature
// - Check City/State/Zip-code feature
// - Check that data prefilled
// - Check image

describe('Fields', function () {
  it('Showed all fields', function () {
  });

  it('Preffilled fields', function () {
  });

describe('Scripts', function () {
  it('Phone feature', function () {
  });

  it('City/State/Zip-code feature', function () {
  });

});
