#!/bin/sh

echo ' '
echo 'ES6 literal string'
time node literal.js
echo ' '
echo '========================='
echo ' '
echo 'ES4 concat string'
time node concat.js
