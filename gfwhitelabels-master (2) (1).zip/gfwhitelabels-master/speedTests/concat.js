var limit = 10000000;
var step = 1;
var name = "Brendan";
var email = "branda@gmail.com";

while(step != limit) {
  var i = 'Yo, ' + name + '! send me msg on: ' + email + ', step: ' + step;
  step ++;
}
